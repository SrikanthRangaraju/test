package api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class ApiTestHelper {

    private List<String> cpfList = new ArrayList<>();
    private List<Map<String, String>> results = new ArrayList<>();
    private final ObjectMapper mapper = new ObjectMapper();

    public void readCpfFile(String fileName) {
        try {
            List<String> lines = Files.readAllLines(Paths.get("src/test/resources/" + fileName));
            cpfList.addAll(lines);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read CPF file", e);
        }
    }

    private String getAccessToken() throws IOException {
        URL url = new URL("https://api-stg.transunion.com.br/auth/1.0/token");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        String body = "grant_type=client_credentials&client_id=CE5CE50DA222CD6FA77B22D92854&client_secret=Testing@12";
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes());
        }
        try (InputStream is = conn.getInputStream()) {
            JsonNode jsonNode = mapper.readTree(is);
            return jsonNode.get("access_token").asText();
        }
    }

    public void callApiForEachCpf() {
        for (String cpf : cpfList) {
            try {
                String token = getAccessToken();
                callEndpointForCpf(cpf, token);
            } catch (Exception e) {
                System.err.println("Error processing CPF " + cpf + ": " + e.getMessage());
            }
        }
    }

    private void callEndpointForCpf(String cpf, String token) throws IOException {
        String url = "https://api-stg.transunion.com.br/bureau/credit-profile/v1/solution/inquiry";

        String requestBody = "{\"pii\":{\"cpf\":{\"cpf\":\"" + cpf + "\"}},\"enquiryPurpose\":\"TS001\",\"isConsent\":\"Y\",\"monitoringDate\":\"20240307\",\"products\":{\"score3D\":{\"isRequested\":\"n\"},\"tvAttributes\":{\"isRequested\":\"y\",\"adviserTemplateId\":\"540975085\"}}}";

        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost post = new HttpPost(url);
        post.setHeader("Authorization", "Bearer " + token);
        post.setHeader("Content-Type", "application/json");
        post.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));

        String response = new String(client.execute(post).getEntity().getContent().readAllBytes());
        parseResponse(cpf, response);
        client.close();
    }

    private void parseResponse(String cpf, String jsonResponse) {
        try {
            JsonNode root = mapper.readTree(jsonResponse);
            JsonNode traits = root.path("productDetails").path("tvAttributes").path("tvAttributesTraits");

            Map<String, String> result = new LinkedHashMap<>();
            result.put("cpfid", cpf);

            if (traits.isObject()) {
                Iterator<String> fields = traits.fieldNames();
                while (fields.hasNext()) {
                    String key = fields.next();
                    String value = traits.get(key).asText();
                    result.put(key, value);
                }
            }

            results.add(result);
        } catch (Exception e) {
            System.err.println("Failed to parse JSON for CPF: " + cpf);
        }
    }

    public void writeOutputToFile(String outputFileName) {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get("src/test/resources/" + outputFileName));
             CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT)) {

            if (!results.isEmpty()) {
                Set<String> headers = results.get(0).keySet();
                printer.printRecord(headers);

                for (Map<String, String> record : results) {
                    List<String> row = new ArrayList<>();
                    for (String header : headers) {
                        row.add(record.getOrDefault(header, ""));
                    }
                    printer.printRecord(row);
                }
            }

        } catch (IOException e) {
            throw new RuntimeException("Failed to write CSV output", e);
        }
    }
}
