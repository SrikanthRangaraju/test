package features;

import api.ApiTestHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CPFAPISteps {

    ApiTestHelper helper = new ApiTestHelper();

    @Given("the list of CPF IDs from {string}")
    public void readCpfFile(String fileName) {
        helper.readCpfFile(fileName);
    }

    @When("I call the API for each CPF ID")
    public void callApi() {
        helper.callApiForEachCpf();
    }

    @Then("I extract tvAttributesTraits and write them to {string}")
    public void writeOutput(String outputFileName) {
        helper.writeOutputToFile(outputFileName);
    }
}
